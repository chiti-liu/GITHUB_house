#include "stm32f10x_exti.h"
#include "control.h"
#include "draw_api.h"
#include "inv_mpu.h"
int flag = 0;
void EXTI9_5_IRQHandler(void) 
{    
	
	if(PBin(5)==1)		
	{		
		EXTI->PR=1<<5;                                           //===���LINE5�ϵ��жϱ�־λ   
		mpu_dmp_get_data(&pitch,&roll,&yaw);
		if(roll>10.0&&roll<60.0)	 flag = 1;
		if(roll<-10.0&&roll>-60.0)	 flag = 2;
		if(pitch<-10.0&&pitch>-60.0) flag = 3;	
		if(pitch>10.0&&pitch<60.0)	 flag = 4;

			

	}    
	
} 
 

int Key_Scan(int flag)
{
  int num;
  switch(flag)
  {
	  case 1 :num= 1;break;
	  case 2 :num= 2;break;
	  case 3 :num= 3;break;
	  case 4 :num= 4;break;
	  default:num= 0;break;
  }
  return num;
}
