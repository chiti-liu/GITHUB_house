#ifndef __CONTROL_H
#define __CONTROL_H
#include "sys.h"

extern float pitch,roll,yaw;
int Key_Scan(int flag);
#endif

