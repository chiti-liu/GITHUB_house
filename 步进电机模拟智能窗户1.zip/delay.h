#ifndef	__DELAY_H
#define	__DELAY_H

#include	"qxmcs51_config.h"

void Delay_us(INT16U ms);
void Delay5us();
#endif
