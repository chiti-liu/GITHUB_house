#ifndef __PCF8591_H
#define __PCF8591_H

//bit I2C_DAC_WriteData(uchar Data);
bit I2C_ADC_ReadData(uchar ADDR, uchar *ADC_Value);

#endif