#ifndef		__STEPMOTOR_H_
#define		__STEPMOTOR_H_
#include "qxmcs51_config.h"
#include "LCD1602.h"
#define MotorData P1                    //����������ƽӿڶ���
void MotorCW();
void MotorCCW();
void MotorStop();
int motor_motion(INT8U Current_ADC,INT8U Pre_ADC);
#endif

