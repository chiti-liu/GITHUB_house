# License-Plate-Recognition
                                                                                                                                    
[点击观看演示视频](https://www.bilibili.com/video/av82600138)                                                                                                           
                                
关注微信公众号：嵌入式基地                                                                                                                                      
后台回复：车牌识别  获取资料                                                                                                           
                                                                                          
 
目前识别汉字，个别英文字母还不准确（识别E和F时会混淆）                                             
                                                                                                                                                                                                          
程序中蜂鸣器与LED的控制已经取消了                                                                                            
                                                                                        
实物图：                                                                             
![picture](https://github.com/Lighter-z/stm32-license-Plate-Recognition/blob/master/%E5%9B%BE%E7%89%87/STM32%E8%BD%A6%E7%89%8C%E8%AF%86%E5%88%AB.png) 
 
