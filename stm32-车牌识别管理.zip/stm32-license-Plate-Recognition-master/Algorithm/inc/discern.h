#ifndef __DISCERN_H
#define __DISCERN_H
	 
#include "stm32f10x.h"
#include "value.h"

void Data_LCD_Display(void);
void CameraScan(void);
void CameraDiscern(void);

#endif

