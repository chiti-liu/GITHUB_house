#ifndef __KEY_H
#define __KEY_H

#ifdef __cplusplus
 extern "C" {
#endif 


void Key_Init(void);	
	 
#ifdef __cplusplus
}
#endif


#endif /* __LTK_KEY_H */

