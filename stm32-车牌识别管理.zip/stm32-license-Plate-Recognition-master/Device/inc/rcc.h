#ifndef __RCC_H
#define __RCC_H
	 
#include "stm32f10x.h"


void STM32_Clock_Init(vu8 PLL);

#endif
